let nome = prompt('Qual é o seu nome?');
if(nome!=null){
    alert('Seja bem vindo, ' + nome);
}
